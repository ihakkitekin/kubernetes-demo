module.exports = {
  echo: function (event, context) {
    const { hello } = require('./hello')
    console.log('context ------>', JSON.stringify(context, null, 4));
    console.log('event.data ------>', JSON.stringify(event.extensions.request.query, null, 4));

    return hello;
  }
}