const hello = "hello, world"

module.exports = {
  hello
}